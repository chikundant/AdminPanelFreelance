from project import app

app.run(port=3000)

